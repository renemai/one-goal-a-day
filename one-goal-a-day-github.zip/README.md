# ⚽ One Goal a Day

Ein kleiner Browser-Prototyp für das Spielkonzept **One Goal a Day**:

> Ein Fußballschuss pro Tag. Alle bekommen dieselbe Challenge. Vergleiche deinen Score mit Freunden.

## Lokal testen

Einfach `index.html` im Browser öffnen.

Für GitHub Pages:
1. Neues GitHub-Repository erstellen.
2. `index.html`, `style.css` und `app.js` hochladen.
3. Unter **Settings → Pages** GitHub Pages aktivieren.
4. Als Quelle den `main`-Branch auswählen.

## Was bereits funktioniert

- Responsive Mobile-UI
- Fußballfeld
- Swipe-/Drag-Schuss
- Schussrichtung und Schusskraft
- einfache Torwart-Reaktion
- Score-Berechnung
- lokaler Bestscore
- Demo-Rangliste
- Share-Button
- tägliche Day-Nummer

## Nächste sinnvolle Schritte

Für eine echte App fehlen vor allem:
- echter Login
- Server/Backend
- echte globale Rangliste
- Freunde und private Challenges
- serverseitig festgelegte Daily Challenge
- Anti-Cheat
- echte Ballphysik
- Push Notifications
- Monetarisierung

Wichtig: Die aktuelle Rangliste ist nur eine lokale Demo und nicht online synchronisiert.
